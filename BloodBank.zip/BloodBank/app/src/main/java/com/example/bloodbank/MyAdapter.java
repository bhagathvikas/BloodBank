package com.example.bloodbank;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    Context context;
    ArrayList<Requests>requests;
    public MyAdapter(Context c, ArrayList<Requests>r)
    {
        context = c;
        requests = r;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.requests_details_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.tvName.setText(requests.get(position).getName());
        holder.tvAge.setText(requests.get(position).getAge());
        holder.tvBloodgroup.setText(requests.get(position).getBloodGroup());
        holder.tvHospital.setText(requests.get(position).getHospital());
        holder.tvPhonenumber.setText(requests.get(position).getPhoneNumber());
        holder.tvGeder.setText(requests.get(position).getGender());

    }

    @Override
    public int getItemCount() {
        return requests.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
        private TextView tvName,tvAge,tvHospital,tvPhonenumber,tvGeder,tvBloodgroup;
        public ItemClickListner listner;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = (TextView)itemView.findViewById(R.id.txtname);
            tvAge = (TextView)itemView.findViewById(R.id.txtage);
            tvHospital = (TextView)itemView.findViewById(R.id.txthospital);
            tvPhonenumber = (TextView)itemView.findViewById(R.id.txtphonenumber);
            tvGeder = (TextView)itemView.findViewById(R.id.txtgender);
            tvBloodgroup = (TextView)itemView.findViewById(R.id.txtbloodgroup);



        }

    }
}
