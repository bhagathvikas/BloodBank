package com.example.bloodbank;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class UserDetailsActivity extends AppCompatActivity {
    private String sUserName,sEmailadd,sPhonenumber,sbloodgrp;
    private Button btnSubmit;
    private EditText Username,Emailaddress,PhoneNumber,Bloodgrp;
    private RadioButton male,female;
    private DatabaseReference users;
    private ProgressDialog progressDialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);



        SharedPreferences preferences = getSharedPreferences("UserDetails",MODE_PRIVATE);

        String FirstTime = preferences.getString("Enter Your Details","");

        if (FirstTime.equals("yes")){

            Intent intent = new Intent(UserDetailsActivity.this, MainScreenActivity.class);
            startActivity(intent);

        }
        else {


            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("Enter Your Details", "yes");
            editor.apply();
        }

        users = FirebaseDatabase.getInstance().getReference().child("user");

        btnSubmit = (Button)findViewById(R.id.btnsubmit);
        Username = (EditText)findViewById(R.id.etusername);
        Emailaddress = (EditText)findViewById(R.id.etemail);
        PhoneNumber = (EditText)findViewById(R.id.etphonenumber);
        Bloodgrp = (EditText)findViewById(R.id.etbloodgrp);
        male = (RadioButton)findViewById(R.id.rbmale);
        female = (RadioButton)findViewById(R.id.rbfemale);
        progressDialog = new ProgressDialog(this);





        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValidateUserDetails();
            }


        });


    }

    private void ValidateUserDetails() {
        sUserName = Username.getText().toString();
        sEmailadd = Emailaddress.getText().toString();
        sPhonenumber = PhoneNumber.getText().toString();
        sbloodgrp = Bloodgrp.getText().toString();

        if (TextUtils.isEmpty(sUserName)){
            Toast.makeText(this, "Enter Username To Continue.." , Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(sEmailadd)){
            Toast.makeText(this, "Enter your Email Id",Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(sbloodgrp)){
            Toast.makeText(this,"Enter Your Blood Group", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(sPhonenumber))

        {
            Toast.makeText(this, "Enter Your Mobile Number", Toast.LENGTH_SHORT).show();

        }
        else {
            SaveTheInformation();
        }
    }

    private void SaveTheInformation() {
        progressDialog.setTitle("msg");
        progressDialog.setMessage("Please Wait...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        SavetheUser();

    }

    private void SavetheUser() {

        HashMap<String, Object> userMap = new HashMap<>();
        userMap.put("Username", sUserName);
        userMap.put("bloodgroup",sbloodgrp);
        userMap.put("phonenumber", sPhonenumber);
        userMap.put("email",sEmailadd);

        users.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    Intent intent = new Intent(UserDetailsActivity.this, MainScreenActivity.class);
                    startActivity(intent);

                    progressDialog.dismiss();
                    Toast.makeText(UserDetailsActivity.this, "Product is added successfully..", Toast.LENGTH_SHORT).show();

                }
                else {
                    progressDialog.dismiss();
                    String message = task.getException().toString();
                    Toast.makeText(UserDetailsActivity.this, "Error: " + message, Toast.LENGTH_SHORT).show();
                }
            }

        });
    }


}
