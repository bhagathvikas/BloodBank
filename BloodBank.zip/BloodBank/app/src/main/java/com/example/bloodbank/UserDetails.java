package com.example.bloodbank;

public class UserDetails {
    private String username, bloodgroup, email, phonenumber;

    public UserDetails() {

    }
    public UserDetails(String username, String bloodgroup, String email, String phonenumber){
        this.username = username;
        this.bloodgroup = bloodgroup;
        this.email = email;
        this.phonenumber = phonenumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }


}
