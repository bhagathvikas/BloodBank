package com.example.bloodbank;

public class BloodGroups {
    public static final String[] bloodGroups = {

            "A+",
            "B+",
            "O+",
            "B-",
            "A-",
            "AB-",
            "AB+",
            "O-"


    };
}
