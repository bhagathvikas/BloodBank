package com.example.bloodbank;

public class CountryData {

    public static final String[] countryNames = {"India"};

    public static final String[] countryAreaCodes = {"91"};
}


