package com.example.bloodbank;
import com.example.bloodbank.UserDetails;

public class Prevalet
{

    public    static UserDetails currentOnlineUser;


    public static final String UserPhoneKey = "UserPhone";
    public  static final  String Usernamekey = "Username";

}
