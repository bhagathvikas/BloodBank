package com.example.bloodbank;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RequestViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    private TextView tvName,tvAge,tvHospital,tvPhonenumber,tvGeder,tvBloodgroup;
    public ItemClickListner listner;


    public RequestViewHolder(@NonNull View itemView) {
        super(itemView);

 tvName = (TextView)itemView.findViewById(R.id.txtname);
        tvAge = (TextView)itemView.findViewById(R.id.txtage);
        tvHospital = (TextView)itemView.findViewById(R.id.txthospital);
        tvPhonenumber = (TextView)itemView.findViewById(R.id.txtphonenumber);
        tvGeder = (TextView)itemView.findViewById(R.id.txtgender);
        tvBloodgroup = (TextView)itemView.findViewById(R.id.txtbloodgroup);


    }
    public void setItemClickListner(ItemClickListner listner)
    {
        this.listner = listner;
    }

    @Override
    public void onClick(View view)
    {
        listner.onClick(view, getAdapterPosition(), false);
    }
}
